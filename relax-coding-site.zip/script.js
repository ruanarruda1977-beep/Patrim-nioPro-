// Basic behavior: Ace editor, run code into iframe, zen mode, examples, ambient sound upload
const editor = ace.edit("editor");
editor.session.setMode("ace/mode/javascript");
editor.setTheme("ace/theme/chrome");
editor.setOptions({ fontSize: 14, wrap: true, showPrintMargin: false });

const runBtn = document.getElementById("runBtn");
const preview = document.getElementById("preview");
const zenBtn = document.getElementById("zenBtn");
const themeSelect = document.getElementById("themeSelect");
const fontSize = document.getElementById("fontSize");
const examples = document.getElementById("examples");
const ambience = document.getElementById("ambience");
const soundToggle = document.getElementById("soundToggle");
const uploadSound = document.getElementById("uploadSound");

function buildPreview(code){
  const html = `
  <html>
  <head>
    <meta charset="utf-8" />
    <style>
      body{margin:0;font-family:Inter,Arial;background:linear-gradient(180deg,#f0fff7,#eaf6f1);min-height:100vh;display:flex;align-items:center;justify-content:center}
      canvas{max-width:100%;height:auto}
    </style>
  </head>
  <body>
    <div id="app"></div>
    <script>
    try {
      ${code}
    } catch(e) {
      document.body.innerHTML = '<pre style="color:#900">Erro: ' + e.message + '</pre>';
      console.error(e);
    }
    </script>
  </body>
  </html>
  `;
  return html;
}

runBtn.addEventListener("click", ()=> {
  const code = editor.getValue();
  preview.srcdoc = buildPreview(code);
});

zenBtn.addEventListener("click", ()=> {
  document.body.requestFullscreen?.();
  document.querySelector('.top').style.display = 'none';
});

themeSelect.addEventListener("change", (e)=>{
  editor.setTheme(e.target.value);
});

fontSize.addEventListener("input", (e)=>{
  editor.setOptions({ fontSize: Number(e.target.value) });
});

examples.addEventListener("change", (e)=>{
  const v = e.target.value;
  if(!v) return;
  if(v==='hello'){
    editor.setValue('console.log("Olá, Relax Coding!");\nalert("Olá! Abra o console no preview (se quiser).");');
  } else if(v==='clock'){
    editor.setValue(`const c=document.createElement('canvas');c.width=400;c.height=400;document.body.appendChild(c);const ctx=c.getContext('2d');function draw(){ctx.clearRect(0,0,c.width,c.height);ctx.fillStyle='#0f8a4f';ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(200,200,80,0,Math.PI*2);ctx.fill();}setInterval(draw,1000/30);`);
  } else if(v==='particles'){
    editor.setValue(`const c=document.createElement('canvas');c.width=600;c.height=400;document.body.appendChild(c);const ctx=c.getContext('2d');let p=[];for(let i=0;i<80;i++)p.push({x:Math.random()*c.width,y:Math.random()*c.height,vy:Math.random()*0.6+0.2});function loop(){ctx.fillStyle='rgba(10,20,10,0.06)';ctx.fillRect(0,0,c.width,c.height);for(let q of p){ctx.fillStyle='rgba(47,157,99,0.9)';ctx.beginPath();ctx.arc(q.x,q.y,2.6,0,Math.PI*2);ctx.fill();q.y+=q.vy; if(q.y>c.height)q.y=0;}requestAnimationFrame(loop);}loop();`);
  }
  e.target.value = '';
});

// Ambient sound - user upload
document.getElementById('uploadSound').addEventListener('change', function(e){
  const f = e.target.files[0];
  if(!f) return;
  const url = URL.createObjectURL(f);
  ambience.src = url;
  soundToggle.checked = true;
  ambience.play().catch(()=>{});
});

soundToggle.addEventListener('change', (e)=>{
  if(e.target.checked) ambience.play().catch(()=>{});
  else ambience.pause();
});

// double-click sound area to upload (UX)
document.querySelector('.switch').addEventListener('dblclick', ()=> uploadSound.click());

// initialize preview with default code
runBtn.click();
