# Relax Coding - Static site scaffold

Este é um site estático simples para "relaxar programando". Principais features:
- Editor (Ace) para JavaScript.
- Preview em iframe (executa o JS).
- Zen Mode (full-screen).
- Upload de áudio ambiente (clicar duas vezes no switch).
- Exemplos e exercícios relax.

## Como usar localmente
1. Abra `index.html` no navegador (ou sirva com um servidor estático: `npx serve` ou `python -m http.server 8080`).
2. Escreva código no editor e clique em "Rodar".
3. Para som ambiente: dê duplo clique no switch e selecione um arquivo de áudio (mp3/ogg).

## Deploy e domínio próprio
Recomendamos Netlify ou Vercel (gratuito para sites estáticos).

**Netlify (passos rápidos)**:
1. Crie conta em netlify.com.
2. Faça drag & drop da pasta `relax-coding-site` (ou do arquivo `index.html`) na área de deploy (Site deploy > Drag and drop your site folder).
3. No painel do site, vá em Domain settings → Add custom domain → siga as instruções.
4. No seu registrador de domínio (GoDaddy, Namecheap, Registro.br), adicione um CNAME apontando para o domínio fornecido por Netlify (ou A records, conforme instruções do Netlify).

**Vercel (passos rápidos)**:
1. Crie conta em vercel.com.
2. `vercel` CLI ou importar o repositório GitHub.
3. Nas Settings → Domains, adicione seu domínio e siga o guia para atualizar DNS no registrador.

## Comprar domínio
- Brasil: registro.br
- Internacional: namecheap.com, godaddy.com, google domains
- Em geral: compre, adicione records (A, CNAME) apontando para provedor de hospedagem e aguarde a propagação (pode levar horas).

## Observações de segurança
- O preview executa código do usuário no iframe. Evite abrir sites inseguros com este editor.
- Para uso com várias pessoas, hospede com HTTPS (Netlify/Vercel já fornecem).

## Próximos passos que posso fazer por você (opções)
1. Gerar um bundle pronto para deploy em Netlify/Vercel e configurar DNS (posso dar o passo-a-passo).
2. Adicionar editor para HTML/CSS também e salvar snippets no localStorage.
3. Criar versão React com autenticação e upload de trilhas sonoras.

Diga qual opção você quer e eu procedo.
